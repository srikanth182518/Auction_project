export class Bidding{
    constructor(public name: string, public amount: number){
        
    }
}